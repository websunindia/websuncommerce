var header_navigation = function(){
	return true;
};